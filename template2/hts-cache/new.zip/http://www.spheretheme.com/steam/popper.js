<!DOCTYPE HTML>
<html>

    <head>
        <title>404 Error - Page Not Found</title>
        <style>
            #ad_frame{ height:800px; width:100%; }
            body{ margin:0; border: 0; padding: 0; }
        </style>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script type="text/javascript" language="JavaScript">
            var url = 'http://www.iyfipgun.com/?dn='
                + document.domain + '&pid=9POL6F2H4';

            $(document).ready(function() {
                $('#ad_frame').attr('src', url);
            });
        </script>
    </head>
    <body>
        <iframe id="ad_frame" src="http://www.iyfipgun.com/"
            frameborder="0" scrolling="no">

            <!-- browser does not support iframe's -->

        </iframe>
    </body>

</html>
